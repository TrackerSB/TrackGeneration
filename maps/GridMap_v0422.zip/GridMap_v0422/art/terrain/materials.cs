new TerrainMaterial()
{
    diffuseMap = "levels/GridMap_v0422/art/terrain/Overlay_02";
    diffuseSize = "20";
    detailMap = "levels/GridMap_v0422/art/terrain/Rock-05-D";
    detailSize = "7";
    detailDistance = "200";
    internalName = "Rock";
    useSideProjection = "0";
    detailStrength = "0.5";
    normalMap = "levels/GridMap_v0422/art/terrain/Rock-05-N";
    parallaxScale = "0";
};
new TerrainMaterial()
{
    diffuseMap = "levels/GridMap_v0422/art/terrain/Overlay_Grass-01";
    detailMap = "levels/GridMap_v0422/art/terrain/Grass-01-D";
    internalName = "Grass";
    diffuseSize = "150";
    detailDistance = "80";
    normalMap = "levels/GridMap_v0422/art/terrain/Grass-01-N";
};

new TerrainMaterial()
{
    diffuseMap = "levels/GridMap_v0422/art/terrain/Overlay_RockyDirt";
    detailMap = "levels/GridMap_v0422/art/terrain/RockyDirt-01-D";
    internalName = "RockyDirt";
    detailDistance = "150";
    detailStrength = "0.6";
    parallaxScale = "0";
    diffuseSize = "100";
    normalMap = "levels/GridMap_v0422/art/terrain/RockyDirt-01-N";
};

new TerrainMaterial()
{
    detailMap = "levels/GridMap_v0422/art/terrain/grid_10_diff";
    internalName = "Grid";
    diffuseMap = "levels/GridMap_v0422/art/terrain/grid_10_diff";
    diffuseSize = "1";
    detailDistance = "2000";
    detailSize = "1";
    macroSize = "10";
    macroStrength = "0.3";
};

new TerrainMaterial()
{
    diffuseMap = "levels/GridMap_v0422/art/terrain/Overlay_mud_1";
    detailMap = "levels/GridMap_v0422/art/terrain/mud_1_d";
    macroSize = "10";
    internalName = "Mud";
    macroStrength = "0.4";
    detailSize = "5";
    detailStrength = "0.6";
    normalMap = "levels/GridMap_v0422/art/terrain/mud_1_n";
};

new TerrainMaterial()
{
    diffuseMap = "levels/GridMap_v0422/art/terrain/Overlay_Sand-01";
    normalMap = "levels/GridMap_v0422/art/terrain/Sand-01-N";
    detailMap = "levels/GridMap_v0422/art/terrain/Sand-01-D";
    internalName = "BeachSand";
    detailSize = "5";
    parallaxScale = "0";
};

new TerrainMaterial()
{
    diffuseMap = "levels/GridMap_v0422/art/terrain/Overlay_Ice-01";
    normalMap = "levels/GridMap_v0422/art/terrain/Ice-01-N";
    detailMap = "levels/GridMap_v0422/art/terrain/Ice-01-D";
    internalName = "Ice";
    detailSize = "1";
    parallaxScale = "0";
   detailStrength = "1";
   diffuseSize = "100";
};

new TerrainMaterial()
{
    diffuseSize = "1";
    detailMap = "levels/GridMap_v0422/art/shapes/buildings/hr_concrete_blocks_d";
    detailSize = "3";
    detailDistance = "2000";
    macroSize = "40";
    macroStrength = "0.5";
    internalName = "Asphalt";
    diffuseMap = "levels/GridMap_v0422/art/shapes/buildings/concrete-01_Macro_d";
    macroMap = "levels/GridMap_v0422/art/shapes/buildings/detail_grunge_03";
    normalMap = "levels/GridMap_v0422/art/shapes/buildings/hr_concrete_blocks_n";
    detailStrength = "0.6";
};
